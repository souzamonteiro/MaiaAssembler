#include <assert.h>
#include <math.h>
#include <stddef.h>
#include <string.h>
#if defined(_MSC_VER)
#include <intrin.h>
#include <malloc.h>
#else
#include <alloca.h>
#endif
