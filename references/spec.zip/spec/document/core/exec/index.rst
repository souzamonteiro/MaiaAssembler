.. _exec:

Execution
=========

.. toctree::
   :maxdepth: 2

   conventions
   runtime
   numerics
   instructions
   modules
