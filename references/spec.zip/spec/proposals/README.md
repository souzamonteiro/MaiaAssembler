# Proposals

This directory contains overviews for post-MVP proposals that have been finished and merged into the spec.
Proposals that are not yet finished can be found at https://github.com/WebAssembly/proposals.

**Note:** The design documents in this folder are archived here for historical purposes and are no longer actively maintained.
Consequently, they may be outdated, contain unfixed errors, or provide insufficient context.
